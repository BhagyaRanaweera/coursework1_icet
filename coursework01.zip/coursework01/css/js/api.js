// Example API Integration (GitHub Repositories)
document.addEventListener('DOMContentLoaded', function() {
    const repoContainer = document.querySelector('#projects');

    fetch('https://api.github.com/users/YOUR_GITHUB_USERNAME/repos')
        .then(response => response.json())
        .then(data => {
            data.forEach(repo => {
                const repoElement = document.createElement('div');
                repoElement.classList.add('project');

                repoElement.innerHTML = `
                    <h3><a href="${repo.html_url}" target="_blank">${repo.name}</a></h3>
                    <p>${repo.description || 'No description available.'}</p>
                `;
                
                repoContainer.appendChild(repoElement);
            });
        })
        .catch(error => console.error('Error fetching repos:', error));
});
